<script setup>
  import { nextTick, ref, watch,  } from "vue";
	import Button from 'primevue/button';

</script>

<template>
    <Button title="입력된값 삭제">
      <span class="blind">삭제</span>
    </Button>
</template>


<style lang="scss" scoped>

</style>