<script setup>
import { ref, onMounted } from 'vue'

const items = ref([])

onMounted(() => {
  // TODO: 다운로드 완료 데이터 조회 로직 구현
})
</script>

<template>
  다운로드완료
</template>

<style lang="scss" scoped>
.completed-download-tab {
  padding: 20px;
}
</style> 