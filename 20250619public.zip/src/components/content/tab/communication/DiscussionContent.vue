<script setup>
</script>

<template>
    <div class="discussion-content">
        토론 게시판 내용이 들어갈 영역입니다.
    </div>
</template> 