<script setup>
  import LayoutSetting from '@/layouts/LayoutSetting.vue'
</script>

<template>
  <LayoutSetting />
</template>