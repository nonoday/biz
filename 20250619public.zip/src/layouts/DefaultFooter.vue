<template>
<div class="footer">
    <div class="footer__innerBox">
        <div class="footer__logo">
            <img src="@images/common/img_footerlogo.png" alt="행정안전부 로고" />
            <img src="@images/common/img_footerklid.png" alt="개발원 로고" />
        </div>
        <p class="footer__address">(30112) 세종특별자치시 도움6로 42 (어진동)</p>
        <div class="footer__other">
            <div class="footer__numberBox">
                <strong class="footer__numberTitle">대표전화</strong>
                <strong class="footer__number">1588-0061</strong> |
                <span>(평일 09~18시, 점심 12~13시)</span>
            </div>
            <p class="footer__copyText">© Ministry of the Interior and Safety. All rights reserved.</p>
        </div>
    </div>
</div>
</template>

<style lang="scss" scoped>
	@use '@/assets/scss/contents/layout/footer.scss';
</style>